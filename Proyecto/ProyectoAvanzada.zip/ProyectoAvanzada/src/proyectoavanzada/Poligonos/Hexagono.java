/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoavanzada.Poligonos;

import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;

/**
 *
 * @author Diali
 */
public class Hexagono implements PoligonosInterface {
    @FXML
    public Pane pane;
    
    Double largo;
    Punto punto;
    
    Line lineaSuperior;
    Line lineaInferior;
    Line lineaSuperiorDerecha;
    Line lineaSuperiorIzquierda;
    Line lineaInferiorDerecha;
    Line lineaInferiorIzquierda;
    
    Punto punto2;
    Punto punto3;
    Punto punto4;
    Punto punto5;
    Punto punto6;
    
    

    public Hexagono(Pane pane, Double largo, Punto punto) {
        this.pane = pane;
        this.largo = largo;
        this.punto = punto;
        punto2= new Punto(punto.getPosX()+largo, punto.getPosY());
        punto3= new Punto(punto.getPosX()+largo*3/2, punto.getPosY()+largo);
        punto4=new Punto(punto.getPosX()+largo, punto.getPosY()+2*largo);
        punto5=new Punto(punto.getPosX(), punto.getPosY()+ 2*largo);
        punto6=new Punto(punto.getPosX()-largo/2, punto.getPosY()+largo);
        
        this.lineaSuperior=new Line(punto.getPosX(), punto.getPosY(),punto2.getPosX(), punto2.getPosY());
        this.lineaSuperiorDerecha= new Line(punto2.getPosX(), punto2.getPosY(), punto3.getPosX(), punto3.getPosY());
        this.lineaInferiorDerecha= new Line( punto3.getPosX(), punto3.getPosY(), punto4.getPosX() , punto4.getPosY());
        this.lineaInferior=new Line(punto4.getPosX() , punto4.getPosY(), punto5.getPosX(), punto5.getPosY());
        this.lineaInferiorIzquierda=new Line(punto5.getPosX(), punto5.getPosY(), punto6.getPosX(), punto6.getPosY());  
        this.lineaSuperiorIzquierda=new Line(punto6.getPosX(), punto6.getPosY(),punto.getPosX(), punto.getPosY() );
    }
    
    
    @Override
    public void Dibujar() {
        lineaSuperior.setStroke(Color.BLACK);
        lineaSuperior.setStrokeWidth(1);
        lineaSuperior.setStrokeLineCap(StrokeLineCap.ROUND);
        pane.getChildren().add(lineaSuperior);
        
        lineaSuperiorDerecha.setStroke(Color.BLACK);
        lineaSuperiorDerecha.setStrokeWidth(1);
        lineaSuperiorDerecha.setStrokeLineCap(StrokeLineCap.ROUND);
        pane.getChildren().add(lineaSuperiorDerecha);
        
        lineaInferiorDerecha.setStroke(Color.BLACK);
        lineaInferiorDerecha.setStrokeWidth(1);
        lineaInferiorDerecha.setStrokeLineCap(StrokeLineCap.ROUND);
        pane.getChildren().add(lineaInferiorDerecha);
        
        lineaInferior.setStroke(Color.BLACK);
        lineaInferior.setStrokeWidth(1);
        lineaInferior.setStrokeLineCap(StrokeLineCap.ROUND);
        pane.getChildren().add(lineaInferior);
        
        lineaInferiorIzquierda.setStroke(Color.BLACK);
        lineaInferiorIzquierda.setStrokeWidth(1);
        lineaInferiorIzquierda.setStrokeLineCap(StrokeLineCap.ROUND);
        pane.getChildren().add(lineaInferiorIzquierda);
        
        lineaSuperiorIzquierda.setStroke(Color.BLACK);
        lineaSuperiorIzquierda.setStrokeWidth(1);
        lineaSuperiorIzquierda.setStrokeLineCap(StrokeLineCap.ROUND);
        pane.getChildren().add(lineaSuperiorIzquierda);
    }

    @Override
    public void Borrar() {
        this.pane.getChildren().remove(this.lineaSuperior);
        this.pane.getChildren().remove(this.lineaSuperiorDerecha);
        this.pane.getChildren().remove(this.lineaInferiorDerecha);
        this.pane.getChildren().remove(this.lineaInferior);
        this.pane.getChildren().remove(this.lineaInferiorIzquierda);
        this.pane.getChildren().remove(this.lineaSuperiorIzquierda);
    }

    @Override
    public void Mover(Punto punto) {
        this.Borrar();
        this.punto.setPosY(punto.getPosY());
        this.punto.setPosX(punto.getPosX());
        
        punto2= new Punto(punto.getPosX()+largo, punto.getPosY());
        punto3= new Punto(punto.getPosX()+largo*3/2, punto.getPosY()+largo);
        punto4=new Punto(punto.getPosX()+largo, punto.getPosY()+2*largo);
        punto5=new Punto(punto.getPosX(), punto.getPosY()+ 2*largo);
        punto6=new Punto(punto.getPosX()-largo/2, punto.getPosY()+largo);
        
        this.lineaSuperior=new Line(punto.getPosX(), punto.getPosY(),punto2.getPosX(), punto2.getPosY());
        this.lineaSuperiorDerecha= new Line(punto2.getPosX(), punto2.getPosY(), punto3.getPosX(), punto3.getPosY());
        this.lineaInferiorDerecha= new Line( punto3.getPosX(), punto3.getPosY(), punto4.getPosX() , punto4.getPosY());
        this.lineaInferior=new Line(punto4.getPosX() , punto4.getPosY(), punto5.getPosX(), punto5.getPosY());
        this.lineaInferiorIzquierda=new Line(punto5.getPosX(), punto5.getPosY(), punto6.getPosX(), punto6.getPosY());  
        this.lineaSuperiorIzquierda=new Line(punto6.getPosX(), punto6.getPosY(),punto.getPosX(), punto.getPosY() );
    }
    
}
