/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoavanzada.Poligonos;

import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;

/**
 *
 * @author Diali
 */
public class Rombo implements PoligonosInterface {
    @FXML
    public Pane pane;
    
    Double largo;
    Punto punto;
    
    Line lineaSuperiorDerecha;
    Line lineaSuperiorIzquierda;
    Line lineaInferiorDerecha;
    Line lineaInferiorIzquierda;

    public Rombo(Pane pane, Double largo, Punto punto) {
        this.pane = pane;
        this.largo = largo;
        this.punto= punto;
        largo=largo/2;
        punto.setPosY(punto.getPosY()-largo);
        punto.setPosX(punto.getPosX()+largo-10);
        this.lineaSuperiorDerecha= new Line(punto.getPosX(),punto.getPosY(),punto.getPosX()+largo,punto.getPosY()+largo);
        this.lineaSuperiorIzquierda= new Line(punto.getPosX(),punto.getPosY(),punto.getPosX()-largo,punto.getPosY()+largo);
        this.lineaInferiorIzquierda= new Line(punto.getPosX(),punto.getPosY()+2*largo,punto.getPosX()-largo,punto.getPosY()+largo);
        this.lineaInferiorDerecha= new Line(punto.getPosX(),punto.getPosY()+2*largo,punto.getPosX()+largo,punto.getPosY()+largo);
    }
    
    @Override
    public void Mover(Punto punto) {
        this.Borrar();
        this.punto.setPosY(punto.getPosY());
        this.punto.setPosX(punto.getPosX());
        this.lineaSuperiorDerecha= new Line(punto.getPosX(),punto.getPosY(),punto.getPosX()+largo,punto.getPosY()+largo);
        this.lineaSuperiorIzquierda= new Line(punto.getPosX(),punto.getPosY(),punto.getPosX()-largo,punto.getPosY()+largo);
        this.lineaInferiorIzquierda= new Line(punto.getPosX(),punto.getPosY()+2*largo,punto.getPosX()-largo,punto.getPosY()+largo);
        this.lineaInferiorDerecha= new Line(punto.getPosX(),punto.getPosY()+2*largo,punto.getPosX()+largo,punto.getPosY()+largo);
        this.Dibujar();
    }
    
    @Override
    public void Dibujar(){
         
            lineaSuperiorDerecha.setStroke(Color.BLACK);
            lineaSuperiorDerecha.setStrokeWidth(1);
            lineaSuperiorDerecha.setStrokeLineCap(StrokeLineCap.ROUND);
            pane.getChildren().add(lineaSuperiorDerecha);
            
            lineaSuperiorIzquierda.setStroke(Color.BLACK);
            lineaSuperiorIzquierda.setStrokeWidth(1);
            lineaSuperiorIzquierda.setStrokeLineCap(StrokeLineCap.ROUND);
            pane.getChildren().add(lineaSuperiorIzquierda);
            
            lineaInferiorIzquierda.setStroke(Color.BLACK);
            lineaInferiorIzquierda.setStrokeWidth(1);
            lineaInferiorIzquierda.setStrokeLineCap(StrokeLineCap.ROUND);
            pane.getChildren().add(lineaInferiorIzquierda);
            
            lineaInferiorDerecha.setStroke(Color.BLACK);
            lineaInferiorDerecha.setStrokeWidth(1);
            lineaInferiorDerecha.setStrokeLineCap(StrokeLineCap.ROUND);
            pane.getChildren().add(lineaInferiorDerecha);
    }
    @Override
    public void Borrar(){
        this.pane.getChildren().remove(this.lineaInferiorDerecha);
        this.pane.getChildren().remove(this.lineaSuperiorIzquierda);
        this.pane.getChildren().remove(this.lineaSuperiorDerecha);
        this.pane.getChildren().remove(this.lineaInferiorIzquierda);
    }
    
}
