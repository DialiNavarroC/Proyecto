/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoavanzada.Poligonos;

import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;

/**
 *
 * @author Diali
 */
public class Triangulo implements PoligonosInterface{
    
    @FXML
    public Pane pane;
    Double largo;
    Double altura;
    Punto punto;
    
    Line lineaSuperior;
    Line lineaInferior;
    Line lineaDerecha;

    public Triangulo(Pane pane, Double largo, Punto punto) {
        this.pane = pane;
        this.largo = largo;
        this.punto= punto;
        this.altura=(1.73*this.largo)/2;
        punto.setPosX(punto.getPosX()-largo/2);
        this.lineaSuperior= new Line(punto.getPosX(),punto.getPosY(),punto.getPosX()+largo/2,punto.getPosY()+this.altura);
        this.lineaInferior= new Line(punto.getPosX(),punto.getPosY(),punto.getPosX()-largo/2,punto.getPosY()+this.altura);
        this.lineaDerecha= new Line(punto.getPosX()+largo/2,punto.getPosY()+this.altura,punto.getPosX()-largo/2,punto.getPosY()+this.altura);
    }
    @Override
    public void Dibujar(){
         
            lineaSuperior.setStroke(Color.BLACK);
            lineaSuperior.setStrokeWidth(1);
            lineaSuperior.setStrokeLineCap(StrokeLineCap.ROUND);
            pane.getChildren().add(lineaSuperior);
            
            lineaInferior.setStroke(Color.BLACK);
            lineaInferior.setStrokeWidth(1);
            lineaInferior.setStrokeLineCap(StrokeLineCap.ROUND);
            pane.getChildren().add(lineaInferior);
            
            
            lineaDerecha.setStroke(Color.BLACK);
            lineaDerecha.setStrokeWidth(1);
            lineaDerecha.setStrokeLineCap(StrokeLineCap.ROUND);
            pane.getChildren().add(lineaDerecha);
    }
    @Override
    public void Borrar(){
        this.pane.getChildren().remove(this.lineaDerecha);
        this.pane.getChildren().remove(this.lineaInferior);
        this.pane.getChildren().remove(this.lineaSuperior);
    }


    @Override
    public void Mover(Punto punto) {
        this.Borrar();
        this.punto= punto;
        punto.setPosX(punto.getPosX()-largo/2);
        this.lineaSuperior= new Line(punto.getPosX(),punto.getPosY(),punto.getPosX()+largo/2,punto.getPosY()+this.altura);
        this.lineaInferior= new Line(punto.getPosX(),punto.getPosY(),punto.getPosX()-largo/2,punto.getPosY()+this.altura);
        this.lineaDerecha= new Line(punto.getPosX()+largo/2,punto.getPosY()+this.altura,punto.getPosX()-largo/2,punto.getPosY()+this.altura);
        this.Dibujar();
    }
    
}
