/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoavanzada.Poligonos;

/**
 *
 * @author Diali
 */
public class Punto {
    private Double posX;
    private Double posY;

    public Punto(Double posX,Double posY) {
        this.posX = posX;
        this.posY = posY;
    }

    public Double getPosX() {
        return posX;
    }

    public Double getPosY() {
        return posY;
    }

    public void setPosX(Double posX) {
        this.posX = posX;
    }

    public void setPosY(Double posY) {
        this.posY = posY;
    }
    
}
